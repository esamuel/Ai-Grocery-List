var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/paypal-plan-check.ts
var paypal_plan_check_exports = {};
__export(paypal_plan_check_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(paypal_plan_check_exports);
var env = (name) => process.env[name] || void 0;
async function getAccessToken(envName) {
  const clientId = envName === "sandbox" ? env("PAYPAL_CLIENT_ID_SANDBOX") || env("VITE_PAYPAL_CLIENT_ID_SANDBOX") : env("PAYPAL_CLIENT_ID") || env("VITE_PAYPAL_CLIENT_ID");
  const secret = envName === "sandbox" ? env("PAYPAL_CLIENT_SECRET_SANDBOX") : env("PAYPAL_CLIENT_SECRET");
  if (!clientId || !secret) {
    throw new Error(`Missing PayPal credentials for ${envName}. Set PAYPAL_CLIENT_ID${envName === "sandbox" ? "_SANDBOX" : ""} and PAYPAL_CLIENT_SECRET${envName === "sandbox" ? "_SANDBOX" : ""} in Netlify env.`);
  }
  const base = envName === "sandbox" ? "https://api-m.sandbox.paypal.com" : "https://api-m.paypal.com";
  const res = await fetch(`${base}/v1/oauth2/token`, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      "Authorization": "Basic " + Buffer.from(`${clientId}:${secret}`).toString("base64")
    },
    body: "grant_type=client_credentials"
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Failed to get token (${res.status}): ${text}`);
  }
  const data = await res.json();
  return { token: data.access_token, base };
}
var handler = async (event) => {
  const origin = event.headers.origin || "*";
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 204,
      headers: {
        "Access-Control-Allow-Origin": origin,
        "Access-Control-Allow-Headers": "Content-Type, Authorization"
      },
      body: ""
    };
  }
  try {
    const params = new URLSearchParams(event.rawQuery || "");
    const envName = params.get("env") === "sandbox" ? "sandbox" : "live";
    const plansParam = params.get("plans") || "";
    const planIds = plansParam.split(",").map((s) => s.trim()).filter(Boolean);
    if (planIds.length === 0) {
      return {
        statusCode: 400,
        headers: { "Access-Control-Allow-Origin": origin },
        body: JSON.stringify({ error: "Missing plans query parameter: plans=P-XXXX,P-YYYY" })
      };
    }
    const { token, base } = await getAccessToken(envName);
    const results = [];
    for (const id of planIds) {
      const res = await fetch(`${base}/v1/billing/plans/${encodeURIComponent(id)}`, {
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json"
        }
      });
      if (!res.ok) {
        const text = await res.text();
        results.push({ id, ok: false, error: `(${res.status}) ${text}` });
        continue;
      }
      const data = await res.json();
      results.push({
        id,
        ok: true,
        status: data.status,
        name: data.name,
        product_id: data.product_id,
        billing_cycles: data.billing_cycles?.map((c) => ({
          frequency: `${c.frequency?.interval_count} ${c.frequency?.interval_unit}`,
          tenure_type: c.tenure_type,
          pricing_scheme: c.pricing_scheme?.fixed_price
        })),
        payment_preferences: data.payment_preferences,
        taxes: data.taxes,
        update_time: data.update_time
      });
    }
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": origin
      },
      body: JSON.stringify({ env: envName, results })
    };
  } catch (err) {
    return {
      statusCode: 500,
      headers: { "Access-Control-Allow-Origin": event.headers.origin || "*" },
      body: JSON.stringify({ error: String(err?.message || err) })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
